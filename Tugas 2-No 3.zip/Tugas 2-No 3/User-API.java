package ${PACKAGE_NAME};
import org.springframework.boot.Spring${NAME};
import org.springframework.boot.autoconfigure.SpringBoot${NAME};

@SpringBoot${NAME}
public class ${NAME} {
    public static void main(String[] args) {
        Spring${NAME}.run(${NAME}.class, args);
    }
}
